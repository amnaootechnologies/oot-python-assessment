"""
OOTechnologies Web Scraping Assessment
--------------------------------------
Implement your scraping logic here.

- Target: https://books.toscrape.com
- Output: data/books.json
- Fields: title, price, availability, rating, product_url
"""
